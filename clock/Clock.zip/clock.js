const setTime = () => {
  const secOut = document.querySelector('.timeOut')
  const minOut = document.querySelector('.minsOut')
  const secHand = document.querySelector('.second-hand')
  const minHand = document.querySelector('.minute-hand')
  
  const initPosition = 90;
  let now = new Date();
  
  let seconds = now.getSeconds();
  let secDegrees = ((seconds / 60) * 360) + initPosition;
  
  if (seconds === 0) {
  	secHand.style.transition = '0s'
  // secHand.style.transform = `rotate(${secDegrees}deg)`
  secHand.style.transform = `rotate(${secDegrees}deg)`
  } else if (seconds >= 1) {
  	secHand.style.transition = '1s'
  }
  secHand.style.transform = `rotate(${secDegrees}deg)`
  
  
}


  setInterval(() => {
    setTime()
  }, 1000);