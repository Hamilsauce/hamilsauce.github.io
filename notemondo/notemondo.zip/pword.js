export class User {
  constructor(password) {
    this.password = password,
    this.authorized = false,
    this.attempts = 0
  }
  newPassword(userInput){
    this.password = userInput;
  }
  validateInput(){}
  checkLogin(userInput){
    let msg = '';
    console.log(this.attempts)
    
    if(this.attempts >= 2) { 
      msg = 'Too many attempts. Goodbye.';
      this.attempts = 0;

      return msg;
    }
    
    let match = userInput == password
      ? true : false;
      
    if (!match) {
      this.authorized = false;
      msg = 'Access Denied.';
      this.attempts++;
      return msg;
    } else {
      this.authorized = true;
      msg = 'Access Granted';
      this.attempts = 0;
      return msg;
    }
      
    
  }
  updateAuth(){}
}

{User}