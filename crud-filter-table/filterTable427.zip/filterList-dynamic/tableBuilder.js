export class DataTable {
  constructor(data, columnNames, parentElement) {
    this.data = data,
      this.columns = columnNames || [],
      this.parentElement = parentElement || document.querySelector('body'),
      this.columnActions = ['sort', 'addFilter', 'highlight']
  }
  createTable() {
    this.table = document.createElement('table');
    this.table.classList.add('datatable')

    this.append(this.createTableBody(), this.table);
    this.append(this.createTableHead(), this.table);
    
    this.append(this.table, this.parentElement);
    console.log(this.table);
  }
  createTableHead() {  //createTableHead accumulates all the output from other header funcs and them appends to tabl
    const thead = this.table.createTHead();
    this.addClass(thead, 'tableHeader');

    const headerRow = thead.insertRow();
    this.addClass(headerRow, 'header-row')

    this.columns
      .forEach((col, index) => {
        const header = this.generateNewEl('th', 'header', index)
     
        if (col.toLowerCase() === 'actions') header = this.addClass('action-header')

        this.append(document.createTextNode(col), header);
        this.append(this.createHeaderMenu(index), header);
        this.append(header, headerRow)
      })
    this.append(headerRow, thead);
    return thead
  }
  createHeaderMenu(index) {
    const menu = this.generateNewEl('ul', 'header-menu', index)
    
    this.columnActions
      .forEach(action => {
        const li = this.generateNewEl('li', 'menu-item', index);
        li.dataset.columnAction = action;

        this.append(document.createTextNode(action), li);
        this.append(li, menu);
      })
    return menu;
  }
  createTableBody() {
   const tableBody = document.createElement('tbody');
    this.addClass(tableBody, 'tableBody')
   this.data.forEach((entry, index) => {
      const newRow = this.table.insertRow()
      newRow.dataset.rowIndex = index + 1;
      this.createRowCells(newRow, entry);
      this.addClass(newRow, 'tableRow')
      
   })
   return tableBody;
  }
  createRowCells(row, entry) {
    Object.entries(entry)
      .forEach(([key, val], index) => {
        console.log(val);
        const cell = row.insertCell();
        cell.dataset.rowIndex = row.dataset.rowIndex;
        this.addIndex(cell, index)
        this.addClass(cell, 'table-field');
  
        this.append(document.createTextNode(val), cell);
      })
  }
  append(newChild, newParent) {
    newParent.appendChild(newChild);
  }
  addClass(el, className) {
    el.classList.add(className)
  }
  addIndex(el, index) {
    el.dataset.columnIndex = index + 1;
  }
  generateNewEl(tag, className, index) {
    const newEl = document.createElement(tag);
    this.addClass(newEl, className);
    this.addIndex(newEl, index);
    return newEl;
  }
}

{ DataTable }