//Util functions
const styleStore = {
  elementReference(el) {
    this.element = el;
  },
  storeBackgroundColor() {
    this.background = this.element.style.backgroundColor;
  },
  storeFontColor() {
    this.fontColor = this.element.style.color;
  },
  getStoredBackround() {
    return this.background;
  },
  getStoredFontColor() {
    return this.fontColor;
  }
}
const appState = {
  filters: []
};
const toggleClass = (el, className) => {
  el.classList.toggle(className)
}
const addClass = (el, className) => {}
const removeClass = (el, className) => {
  el.classList.remove(className)
}
// End Utils

const filterTable = () => {
  const table = document.querySelector("#datatable");
  const tableBody = document.querySelector(".tableBody");
  const headerRow = document.querySelector(".header-row");
  const rows = tableBody.querySelectorAll("tr");
  const input = document.querySelector("#search-input");
  const filter = input.value.toUpperCase();

  for (let i = 0; i < rows.length; i++) {
    const fields = rows[i].querySelectorAll("td");
    let colMatches = 0;

    fields.forEach(field => {
      if (field) {
        let txtValue = field.textContent || field.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          colMatches += 1;
        }
      }
    })
    if (colMatches > 0) {
      rows[i].style.display = "";
    } else {
      rows[i].style.display = "none";
    }
  }
}

document.querySelector('#search-input')
  .addEventListener('keyup', e => {
    filterTable();
  });


const tableBody = document.querySelector(".tableBody");
tableBody.querySelectorAll('tr').forEach((row, index, tableRows) => {
  row.addEventListener('dblclick', e => {
    if (!e.target.classList.contains('table-field')) return;

    let activeField = e.target;
    if (window.activeRowIndex == index) { //tableBody.querySelectorAll('tr').indexOf(row)) {
      stopEdit(activeField, row);
      window.activeRowIndex = -1;
    } else {
      startEdit(activeField, row);
      window.activeRowIndex = index;
    }
  })

  row.addEventListener('blur', e => {
    let activeField = e.target;

    // if (window.activeRowIndex == index) { //tableBody.querySelectorAll('tr').indexOf(row)) {
    stopEdit(activeField, tableRows[window.activeRowIndex]);
    window.activeRowIndex = index;
  })
});

const startEdit = (field, row) => {
  field.focus();
  row.contentEditable = true;
  addClass(field, 'editing')
  addClass(row, 'selectedRow')
  styleStore.elementReference(field);
  styleStore.storeBackgroundColor()
  styleStore.storeFontColor()
  row.style.backgroundColor = 'rgba(255, 255, 255, 1)';
  row.style.color = 'rgba(90, 87, 90, 1);'
// field.style.textDecoration = 'underline';
 row.style.textDecoration = 'underline';
  selectText(field);
}

const stopEdit = (field, row) => {
 row.style.textDecoration = 'none';
  row.style.color = styleStore.getStoredFontColor()
  field.style.backgroundColor = styleStore.getStoredBackround()
  field.style.fontStyle = 'normal';
  removeClass(field, 'editing')
  removeClass(row, 'selectedRow')
  deselectText();
  row.contentEditable = false;
}


//!text select code
const selectText = (el) => {
  if (document.body.createTextRange) {
    let range = document.body.createTextRange();
    range.moveToElementText(el);
    range.select();
  } else if (window.getSelection) {
    let selection = window.getSelection();
    let range = document.createRange();
    range.selectNodeContents(el);
    selection.removeAllRanges();
    selection.addRange(range);
  }
}
const deselectText = () => {
  let wSelection = window.getSelection()
  wSelection.removeAllRanges();
}


//! filter clear button code   - event listeners
document.querySelector('#search-input').addEventListener('keyup', e => {
  const clearButton = document.querySelector('.fa-times-circle')
  const search = e.target;
  filterTable()
  if (search.value.length > 0) {
    addClass(clearButton, 'show')
  } else if (search.value.length === 0) {
    removeClass(clearButton, 'show')
  }
})

document.querySelector('#search-input').addEventListener('change', e => {
  const clearButton = document.querySelector('.fa-times-circle')
  const search = e.target;
  if (search.value.length > 0) {
    addClass(clearButton, 'show')
  } else if (search.value.length === 0) {
    removeClass(clearButton, 'show')
  }
})

document.querySelector('.clearButton').addEventListener('click', e => {
  const search = document.querySelector('#search-input');
  const clearButton = document.querySelector('.fa-times-circle');
  search.value = '';
  filterTable();
  removeClass(e.target, 'show');

})
const tableHeader = document.querySelector('.tableHeader')
tableHeader.querySelectorAll('.header')
  .forEach((head, index) => {
    head.addEventListener('click', e => {
      let menu = head.childNodes[1];
      if (menu.contains(e.target)) return;
      toggleClass(menu, 'show')

      // const col = document.querySelector('.')
      // const col = document.querySelector('.fa-times-circle')
      // col.style.backgroundColor = 'blue'
    })
  });
  
document.querySelectorAll('.header-menu')
  .forEach((menu, index) => {
    menu.childNodes.forEach(li => {
      li.addEventListener('click', e => {
        const targetHeader = e.target
        if (li.dataset.columnAction === 'highlight') {
          highlightColumn(index)
        } else if (li.dataset.columnAction === 'addToFilter'){
          updateFilters(targetHeader)
        }  
        setTimeout((e) => {

          console.log('pooping');
          
          removeClass(menu, 'show')
        }, 600)
      })
    })
  })
  
const highlightColumn = (index) => {
  const column = `col${index + 1}`;
  const fields = document.querySelectorAll(`.${column}`);
  console.log(column);
  console.log(fields);
  fields.forEach(field => {
    toggleClass(field, 'highlight');
  })
}

const updateFilters = (header) => {
  const filters = appState.filters;
  console.log(header.parentNode);
  console.log(header.value);
  if (filters.includes(header.value)) {
    filters.splice(filters.indexOf(header.value), 1)
  } else {
    filters.push(header.value)
  }
  console.log(filters);
}