export const sampleData = [{
    name: "Alfreds Futterkiste",
    country: "Germany"
  },
  {
    name: "Island Trading",
    country: "UK"
  },
  {
    name: "Berglunds snabbkop",
    country: "Sweden"
  },
  {
    name: "Magazzin Riuniti",
    country: "Italy"
  },
  {
    name: "Koniglich Essen",
    country: "Germany"
  },
  {
    name: "Laughing Winecellars",
    country: "Canada"
  },
  {
    name: "North/South",
    country: "UK"
  },
  {
    name: "Paris specialites",
    country: "France"
  }
]

{sampleData}