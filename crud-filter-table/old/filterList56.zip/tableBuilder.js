//TODO: Add ability to inject custom data into the table (file input, copy paste, etc)


export class DataTable {
  constructor(data, columnNames, parentElement) {
    this.data = data,
      this.columns = columnNames || [],
      this.parentElement = parentElement || document.querySelector('body'),
      this.columnActions = ['sort', 'addToFilter', 'highlight']
  }
  createTable() {
    this.table = document.createElement('table');
    this.table.classList.add('datatable');
    const thead = this.createTableHead();
    this.createRows();
    this.createHeaders(thead);


    this.append(this.table, this.parentElement);
  }

  createTableHead() {
    let thead = this.table.createTHead();
    this.addClass(thead, 'tableHeader');
    return thead;
  }

  createHeaders(thead) {
    const headerRow = thead.insertRow();
    this.addClass(headerRow, 'header-row')
    this.columns.forEach((col, index, cols) => {
      const header = this.generateNewEl('th', 'header', index)
      this.appendNewTextNode(col, header);
      this.append(this.createHeaderMenu(index), header);
      this.append(header, headerRow);

      if (index === cols.length - 1) {
        const actionHeader = this.generateNewEl('th', 'action-header', index + 1);
        this.appendNewTextNode('actions', actionHeader);
        this.append(actionHeader, headerRow)
      }
    })
  }

  createHeaderMenu(index) {
    const menu = this.generateNewEl('ul', 'header-menu', index)

    this.columnActions
      .forEach(action => {
        const li = this.generateNewEl('li', 'menu-item', index);
        li.dataset.columnAction = action;
        this.appendNewTextNode(action, li);
        this.append(li, menu);
      })
    return menu;
  }

  createRows() {
    this.data.forEach((entry, index) => { //* Don't need to append or return inserted rows - .insertRows() does appends automatically
      const newRow = this.table.insertRow()
      newRow.dataset.rowIndex = index + 1;

      this.createCells(newRow, entry);
      this.addClass(newRow, 'tableRow')
    })
    //! tbody was automatically created when we inserted rows, so setting class now
  }

  createCells(row, entry) {
    Object.entries(entry)
      .forEach(([key, val], index, fields) => {
        const cell = row.insertCell();
        cell.dataset.rowIndex = row.dataset.rowIndex;
        this.addColumnIndex(cell, index)
        this.addClass(cell, 'table-field');
        this.appendNewTextNode(val, cell);

			  // if the column just completed is the last accprding to header array, build on the actipon column,
        if (index === fields.length - 1) {
          const actionCell = row.insertCell();
          actionCell.dataset.rowIndex = row.dataset.rowIndex;
          this.addColumnIndex(actionCell, index)
          this.addClass(actionCell, 'action-field');
          const deleteRowButton = /*html*/ `<div class="button-wrapper">
            <i class="button-icon deleteRowButton fas fa-trash"></i>
          </div>`;
          const filterRowButton = /*html*/ `<div class="button-wrapper">
            <i class="button-icon filterRowButton fas fa-filter"></i>
          </div>`;
          const undoRowButton = /*html*/ `<div class="button-wrapper">
            <i class="button-icon const undoRowButton fas fa-undo"></i>
          </div>`;
          const pinRowButton = /*html*/ `<div class="button-wrapper pinButton">
            <i class="button-icon pinRowButton fas fa-thumbtack"></i>
          </div>`;

          actionCell.innerHTML += `${pinRowButton} | ${deleteRowButton}`
          // this.appendNewTextNode('action', actionCell)
        }
      })
  }
   
  rebuild(newData) {
    const table = this.table

    while (table.firstChild) {
      table.removeChild(table.firstChild);
    }
    this.data = newData;
    this.createTable();
  }

  append(newChild, newParent) {
    newParent.appendChild(newChild);
  }
  appendNewTextNode(text, newParent) {
    newParent.appendChild(document.createTextNode(text))
  }
  addClass(el, className) {
    el.classList.add(className)
  }
  addColumnIndex(el, index) {
    el.dataset.columnIndex = index + 1;
  }
  addRowIndex(el, index) {
    el.dataset.rowIndex = index;
  }
  generateNewEl(tag, className, index) {
    const newEl = document.createElement(tag);
    this.addClass(newEl, className);
    this.addColumnIndex(newEl, index);
    return newEl;
  }
}



{
  DataTable
}