let cards = [];
 export default cards = [
  {
    id: 0,
    color: "blue"
	},
  {
    id: 1,
    color: "red"
	},
  {
    id: 2,
    color: "purple"
	},
  {
    id: 3,
    color: "yellow"
	},
  {
    id: 4,
    color: "brown"
	},
  {
    id: 5,
    color: "orange"
	},
  {
    id: 6,
    color: "purple"
	},
  {
    id: 7,
    color: "magenta"
	},
  {
    id: 8,
    color: "teal"
	}
]
