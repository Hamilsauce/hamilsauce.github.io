class Chart {
  constructor(chart, columns) {
    this.chart = chart,
      this.columns = columns,
      this.data = data || {}
  }
  setColumn(columnName) {
    this.columns.push()
  }
}
const chartBody = document.querySelector('.grid');
const chart = document.getElementById('chart');

console.log(chart.children);
console.log(chart);

let globalData = {};
globalData.totalConfirmed = parseInt(3755341);
// let chartScale = 6000;
// let chartY = globalData.totalConfirmed / chartScale

fetch('https://covidapi.info/api/v1/global/latest')
  .then(res => res.json())
  .then(data => {
    globalData = Object.values(data.result)
      .map(val => {
        return Object.entries(val)[0]
      })
      .reduce((obj, [key, props]) => {
        let entries = Object.entries(props)
        obj[key] = props;
        return obj
      }, {});

  })

let options = []

fetch('https://hamilsauce.github.io/covid-tracker/data/isocodes.json')
  .then(res => res.json())
  .then(data => {
    let codeList = data;
    options = codeList;
    console.log(options);
setTimeout(() => {
    document.querySelectorAll('.column-name')
      .forEach(name => {
        colNameEvents(options, name)
      })

	
}, 1500);


  })


const initialize = () => {
  const graph = document.querySelector('.grid');
  const columns = graph.querySelectorAll('.column');
  columns.forEach(column => {
    column.style.height = `0px`;
  })
  // graph.style.height = chartY;
}
initialize();

const mapDataToColumn = (code, column) => {
  const graph = document.querySelector('.grid');
  let colVal = column.querySelector('.column-value');
  let chartY = 600;

  let confirmedCases = globalData[code].confirmed || 0;
  setTimeout(() => {
    colHeight = `${((confirmedCases / 2000) * 100  ) / chartY }%`
    console.log(colHeight);
    column.style.height = colHeight
    colVal.textContent = Number(confirmedCases).toLocaleString()
  }, 1000);
}

const colNameEvents = (options, columnName) => {
     makeDataList(options, columnName)
      let listInput = columnName.querySelector('.listInput')

      listInput.addEventListener('blur', e => {
        let ctryName = listInput.value.trim().toUpperCase()
        let codeEntry = options.filter(item => {
       console.log(ctryName);
       console.log(item);
        return item.COUNTRY.trim().toUpperCase() == ctryName
        })
        let iso = codeEntry.CODE
        console.log('code');
        console.log(iso);
        mapDataToColumn(iso, columnName.parentNode)
        // columnName.contentEditable = 'true';
      })
   
}


const makeDataList = (options, newParent) => {
  let listInput = document.createElement('input')
  listInput.setAttribute("list", "codes");
  listInput.classList.add('listInput')

  let list = document.createElement('DATALIST')
  list.setAttribute("id", "codes");

  options .forEach(item => {
    let opt = document.createElement('option')
    opt.setAttribute("value", item.COUNTRY);
    opt.classList.add('code-option')
    opt.dataset.code = item.CODE;
    list.appendChild(opt)
  })
  newParent.appendChild(listInput)
  newParent.appendChild(list)

}

colNameEvents()